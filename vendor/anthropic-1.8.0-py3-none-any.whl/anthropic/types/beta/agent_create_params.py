from __future__ import annotations

from typing import Dict, List, Union, Iterable, Optional
from typing_extensions import Required, TypeAlias, TypedDict

from ..anthropic_beta_param import AnthropicBetaParam
from .beta_managed_agents_model_param import BetaManagedAgentsModelParam
from .beta_managed_agents_skill_params import BetaManagedAgentsSkillParams
from .beta_managed_agents_multiagent_params import BetaManagedAgentsMultiagentParams
from .beta_managed_agents_custom_tool_params import BetaManagedAgentsCustomToolParams
from .beta_managed_agents_mcp_toolset_params import BetaManagedAgentsMCPToolsetParams
from .beta_managed_agents_model_config_params import BetaManagedAgentsModelConfigParams
from .beta_managed_agents_url_mcp_server_params import BetaManagedAgentsURLMCPServerParams
from .beta_managed_agents_agent_toolset20260401_params import BetaManagedAgentsAgentToolset20260401Params

__all__ = ["AgentCreateParams", "Model", "Tool"]


class AgentCreateParams(TypedDict, total=False):
    model: Required[Model]
    """Model identifier.

    Accepts the
    [model string](https://platform.claude.com/docs/en/about-claude/models/overview#latest-models-comparison),
    e.g. `claude-opus-5`, or a `model_config` object for additional configuration
    control
    """

    name: Required[str]
    """Human-readable name for the agent."""

    description: Optional[str]
    """Description of what the agent does."""

    mcp_servers: Iterable[BetaManagedAgentsURLMCPServerParams]
    """MCP servers this agent connects to.

    Maximum 20. Names must be unique within the array. Every server must be
    referenced by an `mcp_toolset` in `tools`; unreferenced servers are rejected.
    See the
    [MCP connector guide](https://platform.claude.com/docs/en/managed-agents/mcp-connector).
    """

    metadata: Dict[str, str]
    """Arbitrary key-value metadata.

    Maximum 16 pairs, keys up to 64 chars, values up to 512 chars.
    """

    multiagent: Optional[BetaManagedAgentsMultiagentParams]
    """
    A coordinator topology: the session's primary thread orchestrates work by
    spawning session threads, each running an agent drawn from the `agents` roster.
    """

    skills: Iterable[BetaManagedAgentsSkillParams]
    """Skills available to the agent."""

    system: Optional[str]
    """System prompt for the agent."""

    tools: Iterable[Tool]
    """Tool configurations available to the agent.

    Maximum of 128 tools across all toolsets allowed.
    """

    betas: List[AnthropicBetaParam]
    """Optional header to specify the beta version(s) you want to use."""

    workspace_id: str
    """Optional header to select the Workspace for this request.

    The value is a Workspace ID (for example, `wrkspc_011CZkZaBF1tNoB5wlCeusgy`).

    Only needed for credentials that can act on more than one Workspace. A
    credential that belongs to a specific Workspace may omit it; if sent, it must
    match that Workspace.
    """


Model: TypeAlias = Union[BetaManagedAgentsModelParam, BetaManagedAgentsModelConfigParams]

Tool: TypeAlias = Union[
    BetaManagedAgentsAgentToolset20260401Params, BetaManagedAgentsMCPToolsetParams, BetaManagedAgentsCustomToolParams
]
