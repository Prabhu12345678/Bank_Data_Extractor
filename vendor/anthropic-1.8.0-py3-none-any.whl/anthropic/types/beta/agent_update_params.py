from __future__ import annotations

from typing import Dict, List, Union, Iterable, Optional
from typing_extensions import TypeAlias, TypedDict

from ..anthropic_beta_param import AnthropicBetaParam
from .beta_managed_agents_model_param import BetaManagedAgentsModelParam
from .beta_managed_agents_skill_params import BetaManagedAgentsSkillParams
from .beta_managed_agents_multiagent_params import BetaManagedAgentsMultiagentParams
from .beta_managed_agents_custom_tool_params import BetaManagedAgentsCustomToolParams
from .beta_managed_agents_mcp_toolset_params import BetaManagedAgentsMCPToolsetParams
from .beta_managed_agents_model_config_params import BetaManagedAgentsModelConfigParams
from .beta_managed_agents_url_mcp_server_params import BetaManagedAgentsURLMCPServerParams
from .beta_managed_agents_agent_toolset20260401_params import BetaManagedAgentsAgentToolset20260401Params

__all__ = ["AgentUpdateParams", "Model", "Tool"]


class AgentUpdateParams(TypedDict, total=False):
    description: Optional[str]
    """Description. Omit to preserve; send empty string or null to clear."""

    mcp_servers: Optional[Iterable[BetaManagedAgentsURLMCPServerParams]]
    """MCP servers.

    Full replacement. Omit to preserve; send empty array or `null` to clear. Names
    must be unique. Maximum 20. Every server must be referenced by an `mcp_toolset`
    in the agent's resulting `tools`; unreferenced servers are rejected. See the
    [MCP connector guide](https://platform.claude.com/docs/en/managed-agents/mcp-connector).
    """

    metadata: Optional[Dict[str, Optional[str]]]
    """Metadata patch.

    Set a key to a string to upsert it, or to null to delete it. Omit the field to
    preserve. The stored bag is limited to 16 keys (up to 64 chars each) with values
    up to 512 chars.
    """

    model: Model
    """Model identifier.

    Accepts the
    [model string](https://platform.claude.com/docs/en/about-claude/models/overview#latest-models-comparison),
    e.g. `claude-opus-5`, or a `model_config` object for additional configuration
    control. Omit to preserve. Cannot be cleared.
    """

    multiagent: Optional[BetaManagedAgentsMultiagentParams]
    """
    A coordinator topology: the session's primary thread orchestrates work by
    spawning session threads, each running an agent drawn from the `agents` roster.
    """

    name: str
    """Human-readable name. Must be non-empty. Omit to preserve. Cannot be cleared."""

    skills: Optional[Iterable[BetaManagedAgentsSkillParams]]
    """Skills. Full replacement. Omit to preserve; send empty array or null to clear."""

    system: Optional[str]
    """System prompt. Omit to preserve; send empty string or null to clear."""

    tools: Optional[Iterable[Tool]]
    """Tool configurations available to the agent.

    Full replacement. Omit to preserve; send empty array or null to clear. Maximum
    of 128 tools across all toolsets allowed.
    """

    version: int
    """The agent's current version, used to prevent concurrent overwrites.

    Obtain this value from a create or retrieve response. Must be at least 1 if
    specified. When supplied, the request fails if it does not match the server's
    current version; omit to apply the update unconditionally.
    """

    betas: List[AnthropicBetaParam]
    """Optional header to specify the beta version(s) you want to use."""

    workspace_id: str
    """Optional header to select the Workspace for this request.

    The value is a Workspace ID (for example, `wrkspc_011CZkZaBF1tNoB5wlCeusgy`).

    Only needed for credentials that can act on more than one Workspace. A
    credential that belongs to a specific Workspace may omit it; if sent, it must
    match that Workspace.
    """


Model: TypeAlias = Union[BetaManagedAgentsModelParam, BetaManagedAgentsModelConfigParams]

Tool: TypeAlias = Union[
    BetaManagedAgentsAgentToolset20260401Params, BetaManagedAgentsMCPToolsetParams, BetaManagedAgentsCustomToolParams
]
