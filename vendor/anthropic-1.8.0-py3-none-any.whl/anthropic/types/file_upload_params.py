from __future__ import annotations

from typing_extensions import Required, TypedDict

from .._types import FileTypes

__all__ = ["FileUploadParams"]


class FileUploadParams(TypedDict, total=False):
    file: Required[FileTypes]
    """The file to upload.

    Only the final path component of the part's `filename` is kept; an absent or
    empty `filename` is replaced with `unnamed` plus the extension for the file's
    stored `mime_type`, when known.
    """

    expires_in_seconds: int
    """
    Seconds from upload until the file expires and its bytes become permanently
    unavailable. Must be between 3600 (one hour) and 7776000 (ninety days).
    """

    workspace_id: str
    """Optional header to select the Workspace for this request.

    The value is a Workspace ID (for example, `wrkspc_011CZkZaBF1tNoB5wlCeusgy`).

    Only needed for credentials that can act on more than one Workspace. A
    credential that belongs to a specific Workspace may omit it; if sent, it must
    match that Workspace.
    """
