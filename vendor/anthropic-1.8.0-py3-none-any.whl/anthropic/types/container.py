from typing import List, Optional
from datetime import datetime

from .._models import BaseModel
from .container_skill import ContainerSkill

__all__ = ["Container"]


class Container(BaseModel):
    """
    Information about the container used in the request (for the code execution tool)
    """

    id: str
    """Identifier for the container used in this request"""

    expires_at: datetime
    """The time at which the container will expire."""

    skills: Optional[List[ContainerSkill]] = None
    """Skills loaded in the container"""
