from .._models import BaseModel
from .beta_currency import BetaCurrency

__all__ = ["BetaMonetaryAmount"]


class BetaMonetaryAmount(BaseModel):
    """A monetary amount in a specific currency."""

    amount: str
    """
    Amount in minor units of the currency, as an integer decimal string with no
    leading zeros: "2500" is $25.00 and "50" is fifty cents. A string rather than a
    number so no float rounding is ever applied.
    """

    currency: BetaCurrency
    """Uppercase ISO-4217 currency code.

    `USD` is the only currency currently supported; the accepted set is closed and
    grows only when a new currency is priced.
    """
