from __future__ import annotations

from typing import List, Optional
from typing_extensions import Literal, Required, TypedDict

from .._types import SequenceNotStr
from .citations_config_param import CitationsConfigParam
from .web_fetch_url_sources_param import WebFetchURLSourcesParam
from .cache_control_ephemeral_param import CacheControlEphemeralParam

__all__ = ["WebFetchTool20260309Param"]


class WebFetchTool20260309Param(TypedDict, total=False):
    """Web fetch tool with use_cache parameter for bypassing cached content."""

    name: Required[Literal["web_fetch"]]
    """Name of the tool.

    This is how the tool will be called by the model and in `tool_use` blocks.
    """

    type: Required[Literal["web_fetch_20260309"]]

    allowed_callers: List[
        Literal["direct", "code_execution_20250825", "code_execution_20260120", "code_execution_20260521"]
    ]

    allowed_domains: Optional[SequenceNotStr[str]]
    """List of domains to allow fetching from"""

    blocked_domains: Optional[SequenceNotStr[str]]
    """List of domains to block fetching from"""

    cache_control: Optional[CacheControlEphemeralParam]
    """Create a cache control breakpoint at this content block."""

    citations: Optional[CitationsConfigParam]
    """Citations configuration for fetched documents.

    Citations are disabled by default.
    """

    defer_loading: bool
    """If true, tool will not be included in initial system prompt.

    Only loaded when returned via tool_reference from tool search.
    """

    max_content_tokens: Optional[int]
    """Maximum number of tokens used by including web page text content in the context.

    The limit is approximate and does not apply to binary content such as PDFs.
    """

    max_uses: Optional[int]
    """Maximum number of times the tool can be used in the API request."""

    strict: bool
    """When true, guarantees schema validation on tool names and inputs"""

    url_sources: Optional[WebFetchURLSourcesParam]
    """Which sources contribute to the set of URLs web fetch may fetch.

    Each key is a tagged variant: `user_input` is `all` or `none`; the two tool
    filters are `all`, `none`, `only` (only the named tools' results) or `except`
    (every result but the named tools'). A named tool must be declared in this
    request's `tools[]`.
    """

    use_cache: bool
    """Whether to use cached content.

    Set to false to bypass the cache and fetch fresh content. Only set to false when
    the user explicitly requests fresh content or when fetching rapidly-changing
    sources.
    """
